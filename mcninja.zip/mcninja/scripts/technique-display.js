//pass array as parameter to display techniques


function displayTechniques(techniqueType) {
  console.log('displaytechniques runs');
  console.log(techniqueType[0])

  techniqueType.filter((punch) => { //hard coded for test
    console.log(punch.id);
  document.querySelector('#technique-display').innerHTML = 
  `
  <hr>
  <button>Previous</button>
  <button>Next</button>
   <div><h1>${punch.techniqueName}</h1></div>
   <div>
    <h2> Safety </h2>
      <p>${punch.safety}</p>
    <h2>Technique Principles</h2>
      <p>${punch.techniquePrinciples.purpose}</p>
      <p>${punch.techniquePrinciples.stance}</p>
      <p>${punch.techniquePrinciples.movement}</p>
    <h2>Technique Fundamentals</h2>
      <p>${punch.techniqueFundamentals.strikingSurface}</p>
      <p>${punch.techniqueFundamentals.targetAreas}</p>
    <h2>Technique Execution</h2>
      <p>${punch.techniqueExecution}</p>
      <p>Pro tip: ${punch.proTip}</p>
    <h2>Video Reference</h2>
      ${punch.video}
        </video>

   </div>

  `
 });
};
