//document event listeners
btnDisplayTanOptions = document.querySelector('#js-display-tan-options');
btnDisplayGrayOptions = document.querySelector('#js-display-gray-options');
btnDisplayGreenOptions = document.querySelector('#js-display-green-options');
btnDisplayBrownOptions = document.querySelector('#js-display-brown-options');
btnDisplayBlackOptions = document.querySelector('#js-display-black-options');

//event listeners for display-belt-options
btnDisplayTanOptions.addEventListener('click', function(){ displayBeltOptions("Tan",); }); //maybe make an array for separate belts but all techniques to pass
btnDisplayGrayOptions.addEventListener('click', function(){ displayBeltOptions("Gray"); });
btnDisplayGreenOptions.addEventListener('click', function(){ displayBeltOptions("Green"); });
btnDisplayBrownOptions.addEventListener('click', function(){ displayBeltOptions("Brown"); });
btnDisplayBlackOptions.addEventListener('click', function(){ displayBeltOptions("Black"); });







