////////////random technique timer
const displayTanTimer = document.querySelector('#display-tan-timer');
const btnBeginRandom = document.querySelector('#js-button-begin-random-tan');
const timerFace = document.querySelector('#timer-face');

btnBeginRandom.addEventListener('click', randomTechniqueTimer)

// array variable
const tanUnarmedTechniques = [
  'a lead hand punch', 'a rear hand punch', 'an uppercut', 'a hook', 'a vertical hammerfist strike', 'a horizontal hammerfist strike', 'a forward angle of movement', 'a rear angle of movement', 'a right angle of movement', 'a left angle of movement', 'a forward-left angle of movement', 'a forward-right angle of movement', 'a rear-left angle of movement', 'a rear-right angle of movement', 'an eye gouge', 'a forward elbow strike', 'a vertical elbow strike, low to high', 'a front kick', 'a round kick', 'a vertical knee strike', ' a vertical stomp', 'a rear choke', 'a figure-4 variation', 'a leg sweep', 'a counter to the rear hand punch', 'a counter to the rear leg kick', 'counter to a rear choke', 'counter to a rear headlock', 'counter to a rear bearhug'];

//set local storage for array recall
function randomTechniqueTimer() {
  displayTanTimer.textContent = `Assume the basic warrior stance.`;

    let countdown = 10;
    setInterval(() => {
      if (countdown >= 1){
        countdown--;
        timerFace.textContent = `${countdown}`
      } else {
        clearInterval()
        countdown = 10;
      }; 
    }, 1000);
 
    setInterval(() => {
      const randomStrike = (tanUnarmedTechniques[(Math.floor(Math.random() * tanUnarmedTechniques.length))]); //get random technique

      if (tanUnarmedTechniques === 0 ) {
        displayTanTimer.textContent =`You have completed all Unarmed Tan Belt Techniques.` // display in html
        console.log("String is empty");
      } else {
        if (countdown >= 1){
          countdown--;
          timerFace.textContent = `${countdown}`
        } else {
          timerFace.textContent = 10;
        };
        const strikeIndex = tanUnarmedTechniques.indexOf(randomStrike); //get index of strike in tanUnarmedTechniques
        tanUnarmedTechniques.splice(strikeIndex, 1); //drop most recently read value from array

        displayTanTimer.textContent = `Execute ${randomStrike}`; //display in html
        console.log(randomStrike); //log random technique for compare
        console.log(tanUnarmedTechniques); //log to see if .splice is dropping random technique 
      }
    }, 10000)  
  };
 

