
 
 function displayBeltOptions(belt, array) {
  console.log("displayBeltOptions runs")
 
    document.querySelector('#display-all-belt-options').innerHTML = 
  `
   <dl class="options-display">
    <button id="js-fundamentals" class="belt-option-button"> ${belt} Fundamentals</button>
    <button id="js-punches" class="belt-option-button"> ${belt} Punches</button>
    <button id="js-falls" class="belt-option-button"> ${belt} Falls</button>
    <button id="js-upper-body-strikes" class="belt-option-button">${belt} Upper Body Strikes</button> 
    <button id="js-lower-body-strikes" class="belt-option-button">${belt} Lower Body Strikes</button> 
    <button id="js-chokes" class="belt-option-button">${belt} Chokes</button> 
    <button id="js-Throws" class="belt-option-button">${belt} Throws</button> 
    <button id="js-counter" class="belt-option-button">${belt} Counters</button> 
    <button id="js-restraints-manipulations" class="belt-option-button">${belt}  Restraints/Manipulations</button> 
    <button id="js-armed-manipulations" class="belt-option-button">${belt} Armed Manipulations</button> 
    <button id="js-knife" class="belt-option-button">${belt} Knife Techniques</button>
    <button id="js-weapons-of-opportunity" class="belt-option-button">${belt} Weapons of Opportunity</button>
    <button id="js-bayonet" class="belt-option-button">${belt} Bayonet Techniques</button>
    <button id="js-bayonet">${belt}  Bayonet Techniques</button>
    <button id="js-ground-fighting">${belt}  Ground Fighting</button>
  </dl>
  `;
  
  

  //even listeners for new buttons
  const btnFundamentals = document.querySelector('#js-fundamentals');
  const btnPunches = document.querySelector('#js-punches');
  const btnFalls = document.querySelector('#js-falls');
  const btnUpperBodyStrikes = document.querySelector('#js-upper-body-strikes');
  const btnLowerBodyStrikes = document.querySelector('#js-lower-body-strikes');
  const btnchokes = document.querySelector('#js-chokes');
  const btnthrows = document.querySelector('#js-punches');
  const btncounters = document.querySelector('#js-punches');
  const btnRestraints = document.querySelector('#js-restraints-manipulations');
  const btnArmedManipulations = document.querySelector('#js-armed-manipulations');
  const btnKnife = document.querySelector('#js-knife');
  const btnWpnsOpportunity = document.querySelector('#js-weapons-of-opportunity');
  const btnGroundFighting = document.querySelector('#js-ground-fighting');
  
  //new event listeners
 // need to make dynamic. maybe use concat array to add all array objects/values together. idk need to get the different techniques and all for each belt
  btnFundamentals.addEventListener('click', () => displayTechniques(techniqueType));
  btnPunches.addEventListener('click', () => displayTechniques(techniqueType)); 
  btnFalls.addEventListener('click', () => displayTechniques(techniqueType));
  btnUpperBodyStrikes.addEventListener('click', () => displayTechniques(techniqueType)); 
  btnLowerBodyStrikes.addEventListener('click', () => displayTechniques(techniqueType)); 
  btnchokes.addEventListener('click', () => displayTechniques(techniqueType)); 
  btnthrows.addEventListener('click', () => displayTechniques(techniqueType)); 
  btncounters.addEventListener('click', () => displayTechniques(techniqueType)); 
  btnRestraints.addEventListener('click', () => displayTechniques(techniqueType)); 
  btnArmedManipulations.addEventListener('click', () => displayTechniques(techniqueType)); 
  btnKnife.addEventListener('click', () => displayTechniques(techniqueType)); 
  btnWpnsOpportunity.addEventListener('click', () => displayTechniques(techniqueType)); 
  btnGroundFighting.addEventListener('click', () => displayTechniques(techniqueType)); 
};
