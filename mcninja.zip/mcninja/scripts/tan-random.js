
//// random technique generator///
//need to make code DRY

// communicate w/ document elements tan unarmed
const displayTanUnarmedTechnique = document.querySelector('#display-tan-unarmed-technique');
const btnRandomTanUnarmed = document.querySelector('#js-btnRandomTanUnarmed');
const btnResetTanUnarmed = document.querySelector('#tan-unarmed-reset');
// communicate w/ document elements tan Bayonet
const displayTanBayonetTechnique = document.querySelector('#display-tan-bayonet-technique');
const btnRandomTanBayonet = document.querySelector('#js-btnRandomTanBayonet');
const btnResetTanBayonet = document.querySelector('#tan-bayonet-reset');
// communicate w/ document elements tan Armed
const displayTanArmedTechnique = document.querySelector('#display-tan-armed-technique');
const btnRandomTanArmed = document.querySelector('#js-btnRandomTanArmed');
const btnResetTanArmed = document.querySelector('#tan-armed-reset');

//array variables for generateRandomTanTechnique function 
  let tanUnarmedTechniques = [
    'a lead hand punch', 'a rear hand punch', 'an uppercut', 'a hook', 'a vertical hammerfist strike', 'a horizontal hammerfist strike', 'a forward angle of movement', 'a rear angle of movement', 'a right angle of movement', 'a left angle of movement', 'a forward-left angle of movement', 'a forward-right angle of movement', 'a rear-left angle of movement', 'a rear-right angle of movement', 'an eye gouge', 'a forward elbow strike', 'a vertical elbow strike, low to high', 'a front kick', 'a round kick', 'a vertical knee strike', ' a vertical stomp', 'a rear choke', 'a figure-4 variation', 'a leg sweep', 'a counter to the rear hand punch', 'a counter to the rear leg kick', 'counter to a rear choke', 'counter to a rear headlock', 'counter to a rear bearhug'];
  let tanBayonetTechniques = ['a forward thrust', 'a vertical buttstroke', 'a horizontal buttstroke', 'a smash', 'a slash', 'a disrupt', 'a counter to the muzzle grab', 'a counter to the overhand grab', 'a counter to the underhand grab', 'a high block', 'a low block', 'a mid block', 'a left block', 'a right block'];
  let tanArmedTechniques = ['a vertical thrust', 'an vertical slash','a vertical thrust', 'an vertical slash','a vertical thrust', 'an vertical slash', 'a vertical thrust', 'an vertical slash']; 

//set local storage for array recall
const tanUnarmedJSON = JSON.stringify(tanUnarmedTechniques);localStorage.setItem("tanUnarmedJSON", tanUnarmedJSON);
const tanBayonetJSON = JSON.stringify(tanBayonetTechniques);localStorage.setItem("tanBayonetJSON", tanBayonetJSON);
const tanArmedJSON = JSON.stringify(tanArmedTechniques);localStorage.setItem("tanArmedJSON", tanArmedJSON);


//function random button for tan unarmed
function generateTanUnarmedTechnique() {
    const randomStrike = (tanUnarmedTechniques[(Math.floor(Math.random(tanUnarmedTechniques) * tanUnarmedTechniques.length))]); //get random technique

      if (tanUnarmedTechniques == "" ) {
        displayTanUnarmedTechnique.textContent =`You have completed all Unarmed Tan Belt Techniques.` // display in html
        console.log("String is empty");
      } else {
        const strikeIndex = tanUnarmedTechniques.indexOf(randomStrike); //get index of strike in tanUnarmedTechniques
        tanUnarmedTechniques.splice(strikeIndex, 1); //drop most recently read value from array

        displayTanUnarmedTechnique.textContent = `Execute ${randomStrike}`; //display in html
        console.log(randomStrike); //log random technique for compare
        console.log(tanUnarmedTechniques); //log to see if .splice is dropping random technique
      }
      notifyComplete();   
};


//function random button for tan Bayonet
function generateTanBayonetTechnique() {
  const randomStrike = (tanBayonetTechniques[(Math.floor(Math.random(tanBayonetTechniques) * tanBayonetTechniques.length))]); //get random technique

    if (tanBayonetTechniques == "" ) {
      displayTanBayonetTechnique.textContent =`You have completed all Tan Belt Bayonet Techniques.` // display in html
      console.log("String is empty");
    } else {
      const strikeIndex = tanBayonetTechniques.indexOf(randomStrike); //get index of strik in tanBayonetTechniques
      tanBayonetTechniques.splice(strikeIndex, 1); //drop most recently read value from array

      displayTanBayonetTechnique.textContent = `Execute ${randomStrike}`; //display in html
      console.log(randomStrike); //log random technique for compare
      console.log(tanBayonetTechniques); //log to see if .splice is dropping random technique
    }
  notifyComplete(); 
};


//function random button for tan Armed
function generateTanArmedTechnique() {
  const randomStrike = (tanArmedTechniques[(Math.floor(Math.random(tanArmedTechniques) * tanArmedTechniques.length))]); //get random technique

    if (tanArmedTechniques == "" ) {
      displayTanArmedTechnique.textContent =`You have completed all Armed Tan Belt Techniques.` // display in html
      console.log("String is empty");
    } else {
      const strikeIndex = tanArmedTechniques.indexOf(randomStrike); //get index of strik in tanArmedTechniques
      tanArmedTechniques.splice(strikeIndex, 1); //drop most recently read value from array

      displayTanArmedTechnique.textContent = `Execute ${randomStrike}`; //display in html
      console.log(randomStrike); //log random technique for compare
      console.log(tanArmedTechniques); //log to see if .splice is dropping random technique
    }
    notifyComplete();   
};


//reset tan unarmed
function handleResetTanUnarmed(){ //get JSON and apply to tanUnarmedTechniques
  let retrievetanUnarmedJSON = localStorage.getItem("tanUnarmedJSON");
  tanUnarmedTechniques = JSON.parse(retrievetanUnarmedJSON);
  
  displayTanUnarmedTechnique.textContent = `Assume the Basic Warrior Stance`
 
  console.log('string is reset');
  console.log(tanUnarmedTechniques);
};
//reset tan Bayonet
function handleResetTanBayonet(){ //get JSON and apply to tanBayonetTechniques
  let retrievetanBayonetJSON = localStorage.getItem("tanBayonetJSON");
  tanBayonetTechniques = JSON.parse(retrievetanBayonetJSON);
  
  displayTanBayonetTechnique.textContent = `Assume the Basic Warrior Stance`
  
  console.log('string is reset');
  console.log(tanBayonetTechniques);
  };
//reset tan Armed
function handleResetTanArmed(){ //get JSON and apply to tanArmedTechniques
let retrievetanArmedJSON = localStorage.getItem("tanArmedJSON");
tanArmedTechniques = JSON.parse(retrievetanArmedJSON);

displayTanArmedTechnique.textContent = `Assume the Basic Warrior Stance`

console.log('string is reset');
console.log(tanArmedTechniques);
};


function notifyComplete() {
  if (tanUnarmedTechniques == "" && tanBayonetTechniques == "" && tanArmedTechniques == "") {
    alert("You have completed all of the Tan Belt physical disciplines that do not require a partner.");
  } else {
    console.log(`There are more Tan Belt Techniques to complete.`);
  };
}

