const beltTechniqueArray = [
{
  id: "",
  techniqueName: "",
  techniqueEquipment: [],
  safety: ``,
  techniquePrinciples: {
    purpose:"",
    principlesOverview: ``,
    grip: "",
    stance: "",
    movement:"",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    
    `,
  proTip: "",
  video: ``,
},
]; 