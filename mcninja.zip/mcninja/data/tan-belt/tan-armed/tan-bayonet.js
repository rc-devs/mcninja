const tanBayonet = [{
  id: "TanBayonet1",
  techniqueName: "Straight Thrust",
  techniqueEquipment: ['Rifle/Training Rifle or Staff'],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.    
    c. Do not make contact on the partners with the weapon.
    d. Before training with firearms, unload and show clear.
    e. When handling firearms, the weapons safety rules apply.
        (1) Treat every weapon as if it were loaded.
        (2) Never point a weapon at anything you do not intend to shoot.
        (3) Keep your finger straight and off the trigger until you are ready to fire.
        (4) Keep your weapon on “safe” until you intend to fire.
  `,
  techniquePrinciples: {
    purpose:"The purpose of bayonet techniques is to disable or kill an aggressor.",
    grip: 
    `
    It is possible to execute these bayonet techniques while gripping the buttstock of the weapon, but the stress is on being able to execute them from the pistol grip. These are lethal, offensive techniques that can be used in conjunction with assault fire movement.
        (a) Grab the pistol grip with your right hand. Keep your trigger finger off the trigger and included it in the grip.
        (b) With the left hand, grab the hand guards of the rifle under-handed.
        (c) Lock the buttstock of the rifle against the hip with the right forearm.
        (d) Keep movements of the bayonet blade within a box, shoulder width across from your neck down to your waistline. Always keep the bayonet end of the rifle oriented toward the aggressor.
`,
    stance: "All movement begins and ends with the modified basic warrior stance. Create a smaller silhouette and lower center of gravity by lowering your body at the knees and create “eye-muzzle-target” toward the aggressor.",
    movement:"Movement is used to get from one place to another when the threat of contact is imminent. Use a controlled and steady combat glide to avoid tripping while moving toward the aggressor.",
  },
  techniqueFundamentals: {
    strikingSurface: "Thrusts will use the point of the bayonet and slashes will use the cutting edge of the bayonet. Buttstrokes will use the toe of the buttstock off the rifle and smashes will use the butt of the rifle.",
    targetAreas: "The primary target areas of the body are the aggressors throat, groin, or face. The aggressor’s torso can be another target area if it is not protected by body armor.",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    The straight thrust is the most deadly offensive technique because it will cause the most trauma to an aggressor and is the primary offensive bayonet technique.
        (1) From the modified basic warrior stance, step forward with your lead leg, driving off the ball of your rear foot.
        (2) At the same time, thrust the blade end of the weapon directly toward the aggressor by thrusting both hands forward.
        (3) Retract the weapon and return to the basic warrior stance by stepping forward with the rear foot.
    `,
  proTip: "",
}, { 
  id: "TanBayonet2",
  techniqueName: "Slash",
  techniqueEquipment: ['Rifle/Training Rifle or Staff'],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.    
    c. Do not make contact on the partners with the weapon.
    d. Before training with firearms, unload and show clear.
    e. When handling firearms, the weapons safety rules apply.
        (1) Treat every weapon as if it were loaded.
        (2) Never point a weapon at anything you do not intend to shoot.
        (3) Keep your finger straight and off the trigger until you are ready to fire.
        (4) Keep your weapon on “safe” until you intend to fire.
  `,
  techniquePrinciples: {
    purpose:"The purpose of bayonet techniques is to disable or kill an aggressor.",
    grip: 
    `
    It is possible to execute these bayonet techniques while gripping the buttstock of the weapon, but the stress is on being able to execute them from the pistol grip. These are lethal, offensive techniques that can be used in conjunction with assault fire movement.
        (a) Grab the pistol grip with your right hand. Keep your trigger finger off the trigger and included it in the grip.
        (b) With the left hand, grab the hand guards of the rifle under-handed.
        (c) Lock the buttstock of the rifle against the hip with the right forearm.
        (d) Keep movements of the bayonet blade within a box, shoulder width across from your neck down to your waistline. Always keep the bayonet end of the rifle oriented toward the aggressor.
`,
    stance: "All movement begins and ends with the modified basic warrior stance. Create a smaller silhouette and lower center of gravity by lowering your body at the knees and create “eye-muzzle-target” toward the aggressor.",
    movement:"Movement is used to get from one place to another when the threat of contact is imminent. Use a controlled and steady combat glide to avoid tripping while moving toward the aggressor.",
  },
  techniqueFundamentals: {
    strikingSurface: "Thrusts will use the point of the bayonet and slashes will use the cutting edge of the bayonet. Buttstrokes will use the toe of the buttstock off the rifle and smashes will use the butt of the rifle.",
    targetAreas: "The primary target areas of the body are the aggressors throat, groin, or face. The aggressor’s torso can be another target area if it is not protected by body armor.",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    The slash is used to cut through the aggressor’s defenses or to kill him. It is best to follow up the slash with a thrust to maximize the damage and trauma to the aggressor.
        (1) From the modified basic warrior stance retract the left hand slightly toward the left shoulder.
        (2) Bring the left hand down and to the right (diagonally) cutting through the target with the blade. To generate more power take a small step with your left foot when you slash, rapidly bringing your right foot back up to the modified basic warrior stance.
    `,
  proTip: "",
},{ 
  id: "TanBayonet3",
  techniqueName: "Vertical Buttstroke",
  techniqueEquipment: ['Rifle/Training Rifle or Staff'],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.    
    c. Do not make contact on the partners with the weapon.
    d. Before training with firearms, unload and show clear.
    e. When handling firearms, the weapons safety rules apply.
        (1) Treat every weapon as if it were loaded.
        (2) Never point a weapon at anything you do not intend to shoot.
        (3) Keep your finger straight and off the trigger until you are ready to fire.
        (4) Keep your weapon on “safe” until you intend to fire.
  `,
  techniquePrinciples: {
    purpose:"The purpose of bayonet techniques is to disable or kill an aggressor.",
    grip: 
    `
    It is possible to execute these bayonet techniques while gripping the buttstock of the weapon, but the stress is on being able to execute them from the pistol grip. These are lethal, offensive techniques that can be used in conjunction with assault fire movement.
        (a) Grab the pistol grip with your right hand. Keep your trigger finger off the trigger and included it in the grip.
        (b) With the left hand, grab the hand guards of the rifle under-handed.
        (c) Lock the buttstock of the rifle against the hip with the right forearm.
        (d) Keep movements of the bayonet blade within a box, shoulder width across from your neck down to your waistline. Always keep the bayonet end of the rifle oriented toward the aggressor.
`,
    stance: "All movement begins and ends with the modified basic warrior stance. Create a smaller silhouette and lower center of gravity by lowering your body at the knees and create “eye-muzzle-target” toward the aggressor.",
    movement:"Movement is used to get from one place to another when the threat of contact is imminent. Use a controlled and steady combat glide to avoid tripping while moving toward the aggressor.",
  },
  techniqueFundamentals: {
    strikingSurface: "Thrusts will use the point of the bayonet and slashes will use the cutting edge of the bayonet. Buttstrokes will use the toe of the buttstock off the rifle and smashes will use the butt of the rifle.",
    targetAreas: "The primary target areas of the body are the aggressors throat, groin, or face. The aggressor’s torso can be another target area if it is not protected by body armor.",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    The vertical buttstroke is used to weaken the aggressor’s defenses, to cause serious injury, or to create space to set him up for a killing blow. It is best executed after a thrust but should always be followed by a slash and a thrust.
        (1) From the modified basic warrior stance step forward with your right foot and drive your right elbow forward, straight up while moving your left hand back toward your left ear.
        (2) Rotate the hips and shoulders, rising slightly, driving with your legs to generate power.
        (3) Return to the modified basic warrior stance by stepping forward with your left foot and bringing your weapon down executing a slash.
    `,
  proTip: "",
},{ 
  id: "TanBayonet4",
  techniqueName: "Horizontal Buttstroke",
  techniqueEquipment: ['Rifle/Training Rifle or Staff'],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.    
    c. Do not make contact on the partners with the weapon.
    d. Before training with firearms, unload and show clear.
    e. When handling firearms, the weapons safety rules apply.
        (1) Treat every weapon as if it were loaded.
        (2) Never point a weapon at anything you do not intend to shoot.
        (3) Keep your finger straight and off the trigger until you are ready to fire.
        (4) Keep your weapon on “safe” until you intend to fire.
  `,
  techniquePrinciples: {
    purpose:"The purpose of bayonet techniques is to disable or kill an aggressor.",
    grip: 
    `
    It is possible to execute these bayonet techniques while gripping the buttstock of the weapon, but the stress is on being able to execute them from the pistol grip. These are lethal, offensive techniques that can be used in conjunction with assault fire movement.
        (a) Grab the pistol grip with your right hand. Keep your trigger finger off the trigger and included it in the grip.
        (b) With the left hand, grab the hand guards of the rifle under-handed.
        (c) Lock the buttstock of the rifle against the hip with the right forearm.
        (d) Keep movements of the bayonet blade within a box, shoulder width across from your neck down to your waistline. Always keep the bayonet end of the rifle oriented toward the aggressor.
`,
    stance: "All movement begins and ends with the modified basic warrior stance. Create a smaller silhouette and lower center of gravity by lowering your body at the knees and create “eye-muzzle-target” toward the aggressor.",
    movement:"Movement is used to get from one place to another when the threat of contact is imminent. Use a controlled and steady combat glide to avoid tripping while moving toward the aggressor.",
  },
  techniqueFundamentals: {
    strikingSurface: "Thrusts will use the point of the bayonet and slashes will use the cutting edge of the bayonet. Buttstrokes will use the toe of the buttstock off the rifle and smashes will use the butt of the rifle.",
    targetAreas: "The primary target areas of the body are the aggressors throat, groin, or face. The aggressor’s torso can be another target area if it is not protected by body armor.",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    The horizontal buttstroke is used to weaken an aggressor's defenses, to cause serious injury, or to create space to set him up for a killing blow. It is best executed after a thrust but should always be followed by a slash and a thrust.
        (1) From the modified basic warrior stance step forward with your right foot and drive your right elbow forward, parallel to the deck while moving your left hand back toward your left shoulder.
        (2) Rotate the hips and shoulders into the strike to generate power.
        (3) Return to the modified basic warrior stance by stepping forward with your left foot and bringing your weapon back executing a slash.
    `,
  proTip: "",
},{ 
  id: "TanBayonet5",
  techniqueName: "Smash",
  techniqueEquipment: ['Rifle/Training Rifle or Staff'],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.    
    c. Do not make contact on the partners with the weapon.
    d. Before training with firearms, unload and show clear.
    e. When handling firearms, the weapons safety rules apply.
        (1) Treat every weapon as if it were loaded.
        (2) Never point a weapon at anything you do not intend to shoot.
        (3) Keep your finger straight and off the trigger until you are ready to fire.
        (4) Keep your weapon on “safe” until you intend to fire.
  `,
  techniquePrinciples: {
    purpose:"The purpose of bayonet techniques is to disable or kill an aggressor.",
    grip: 
    `
    It is possible to execute these bayonet techniques while gripping the buttstock of the weapon, but the stress is on being able to execute them from the pistol grip. These are lethal, offensive techniques that can be used in conjunction with assault fire movement.
        (a) Grab the pistol grip with your right hand. Keep your trigger finger off the trigger and included it in the grip.
        (b) With the left hand, grab the hand guards of the rifle under-handed.
        (c) Lock the buttstock of the rifle against the hip with the right forearm.
        (d) Keep movements of the bayonet blade within a box, shoulder width across from your neck down to your waistline. Always keep the bayonet end of the rifle oriented toward the aggressor.
`,
    stance: "All movement begins and ends with the modified basic warrior stance. Create a smaller silhouette and lower center of gravity by lowering your body at the knees and create “eye-muzzle-target” toward the aggressor.",
    movement:"Movement is used to get from one place to another when the threat of contact is imminent. Use a controlled and steady combat glide to avoid tripping while moving toward the aggressor.",
  },
  techniqueFundamentals: {
    strikingSurface: "Thrusts will use the point of the bayonet and slashes will use the cutting edge of the bayonet. Buttstrokes will use the toe of the buttstock off the rifle and smashes will use the butt of the rifle.",
    targetAreas: "The primary target areas of the body are the aggressors throat, groin, or face. The aggressor’s torso can be another target area if it is not protected by body armor.",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    The smash is used as a follow-on technique to the vertical or horizontal buttstroke, primarily when the target was missed on a buttstroke or to gain proper striking distance for close-in engagements.
        (1) Start from step one of the vertical or horizontal buttstroke. Your right foot should be forward with the blade end of the weapon over your left shoulder, weapon roughly parallel to the deck.
        (2) Step forward with your right foot, driving off of your left foot to generate power. Strike the aggressor with the butt stock of the weapon by thrusting the weapon toward your aggressor.
        (3) As you retract the weapon back to the starting position, take a small step forward with the left leg. Do not jump or hop.
        (4) Return to the modified basic warrior stance by stepping forward with your left foot and executing a slash.
    `,
  proTip: "",
},{ 
  id: "TanBayonet6",
  techniqueName: "Disrupt",
  techniqueEquipment: ['Rifle/Training Rifle or Staff'],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.    
    c. Do not make contact on the partners with the weapon.
    d. Before training with firearms, unload and show clear.
    e. When handling firearms, the weapons safety rules apply.
        (1) Treat every weapon as if it were loaded.
        (2) Never point a weapon at anything you do not intend to shoot.
        (3) Keep your finger straight and off the trigger until you are ready to fire.
        (4) Keep your weapon on “safe” until you intend to fire.
  `,
  techniquePrinciples: {
    purpose:"The purpose of bayonet techniques is to disable or kill an aggressor.",
    grip: 
    `
    It is possible to execute these bayonet techniques while gripping the buttstock of the weapon, but the stress is on being able to execute them from the pistol grip. These are lethal, offensive techniques that can be used in conjunction with assault fire movement.
        (a) Grab the pistol grip with your right hand. Keep your trigger finger off the trigger and included it in the grip.
        (b) With the left hand, grab the hand guards of the rifle under-handed.
        (c) Lock the buttstock of the rifle against the hip with the right forearm.
        (d) Keep movements of the bayonet blade within a box, shoulder width across from your neck down to your waistline. Always keep the bayonet end of the rifle oriented toward the aggressor.
`,
    stance: "All movement begins and ends with the modified basic warrior stance. Create a smaller silhouette and lower center of gravity by lowering your body at the knees and create “eye-muzzle-target” toward the aggressor.",
    movement:"Movement is used to get from one place to another when the threat of contact is imminent. Use a controlled and steady combat glide to avoid tripping while moving toward the aggressor.",
  },
  techniqueFundamentals: {
    strikingSurface: "Thrusts will use the point of the bayonet and slashes will use the cutting edge of the bayonet. Buttstrokes will use the toe of the buttstock off the rifle and smashes will use the butt of the rifle.",
    targetAreas: "The primary target areas of the body are the aggressors throat, groin, or face. The aggressor’s torso can be another target area if it is not protected by body armor.",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    A disrupt is used as a defensive technique to redirect or deflect an attack in preparation for executing a thrust or other appropriate offensive bayonet techniques. A disrupt is a slight redirection of an aggressor’s linear attack such as a straight thrust or a smash.
      (1) With the weapon locked against the hip with the right forearm, rotate the body to the right or left, moving the bayonet end of the rifle to disrupt the aggressor's attack. Rotation should generate from the hips.
      (2) Contact is made with the bayonet end of the rifle against the barrel or bayonet of the aggressor's weapon.
      (3) Redirect or guide the aggressor's weapon away from your body by exerting pressure against the aggressor's weapon with your weapon. The disrupt should be executed with an economy of motion. You only need to redirect the aggressor's weapon a couple of inches to have the weapon miss your body.
    `,
  proTip: "",
}
];