const tanArmedManipulations = [
{
  id: "01-Armed-Tan",
  techniqueName: "Counter to the Muzzle Grab",
  techniqueEquipment: [],
  safety: ``,
  techniquePrinciples: {
    purpose:"",
    grip: "",
    stance: "",
    movement:"",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    
    `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/HWCpjkHUTQY?si=UHergF1UtP9kypKn" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},
{
  id: "02-Armed-Tan",
  techniqueName: "Counter to the Overhand Grab",
  techniqueEquipment: [],
  safety: ``,
  techniquePrinciples: {
    purpose:"",
    grip: "",
    stance: "",
    movement:"",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    
    `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/PGPmGDzbxOI?si=Sgt0kK0xHspuS32v" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},
{
  id: "03-Armed-Tan",
  techniqueName: "Counter to the Underhand Grab",
  techniqueEquipment: [],
  safety: ``,
  techniquePrinciples: {
    purpose:"",
    grip: "",
    stance: "",
    movement:"",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    
    `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/PGPmGDzbxOI?si=x7C-7zXt9EBvdABF" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},
{
  id: "04-Armed-Tan",
  techniqueName: "High Block",
  techniqueEquipment: [],
  safety: ``,
  techniquePrinciples: {
    purpose:"",
    grip: "",
    stance: "",
    movement:"",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    
    `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/gXUX1-JPR_o?si=5gDKXaZDXCULlAVK" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},
{
  id: "05-Armed-Tan",
  techniqueName: "Low Block",
  techniqueEquipment: [],
  safety: ``,
  techniquePrinciples: {
    purpose:"",
    grip: "",
    stance: "",
    movement:"",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    
    `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/9kKRQgt_6W0?si=JNhjv7hIqFl2EZMx" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},
{
  id: "06-Armed-Tan",
  techniqueName: "Mid Block",
  techniqueEquipment: [],
  safety: ``,
  techniquePrinciples: {
    purpose:"",
    grip: "",
    stance: "",
    movement:"",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    
    `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/9kKRQgt_6W0?si=JNhjv7hIqFl2EZMx" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},
{
  id: "07-Armed-Tan",
  techniqueName: "Left Block",
  techniqueEquipment: [],
  safety: ``,
  techniquePrinciples: {
    purpose:"",
    grip: "",
    stance: "",
    movement:"",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    
    `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/ZzfyFFFTK4Q?si=jVlzMy8XJZWuDCRV" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},
{
  id: "08-Armed-Tan",
  techniqueName: "Right Block",
  techniqueEquipment: [],
  safety: ``,
  techniquePrinciples: {
    purpose:"",
    grip: "",
    stance: "",
    movement:"",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    
    `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/5UNhGnOuUkM?si=nPc5voPXvJOboISg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},
]; 