const tanKnife = [{
  id: "TanKnife1",
  techniqueName:'Vertical Thrust',
  techniqueEquipment: ['Mouthpiece', 'Training Knife'],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.
    c. Do not make contact on the aggressor with the weapon.
    d. Conduct all practical application utilizing approved training gear.
  `,
  techniquePrinciples: {
    purpose:"The purpose of knife techniques is to kill the aggressor or cause enough damage to stop their attack.",
    grip: "Your grip on the knife should be a natural and relaxed hammer grip with enough strength to hold the weapon while maintaining dexterity. From this position, the blade of the knife is always facing the aggressor.",
    stance: "The basic warrior stance is the foundation for knife techniques. The left arm will serve as a vertical shield protecting the head, neck, and torso. The weapon should be held at a level between the belt and chest, tight to the body to facilitate weapon retention.",
    movement:"Movement is used to open up different target areas of the body and avoid the aggressor’s strikes. Do not stand directly in front of the aggressor; they can rely on forward momentum to create the tactical advantage.",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "The objective in a knife fight is to attack vital target areas readily accessible such as the face, neck, torso, and groin. The extremities are secondary targets that are not immediately fatal, but will often open up fatal target areas, or become fatal if left unattended",
    anglesOfAttack: "There are six angles from which a knife attack can be launched: Vertically up or down, forward diagonal, reverse diagonal, forward horizontal, reverse horizontal, and a straight thrust.",
  },
  techniqueExecution: 
    `
    Slashing techniques are used to cut the aggressor and/or open them up for follow-on techniques. Slashing distracts the aggressor or causes enough damage to get in close to the aggressor.

        (1) Start facing the aggressor in the modified basic warrior stance.
        (2) Thrust your right hand out and bring the weapon straight down on the aggressor.
        (3) Continue dragging the knife down through the aggressor's body. Maintain contact on the aggressor's body with the blade of the knife. The slashing motion follows a vertical line straight down through the target.
        (4) Return to the modified basic warrior stance.
          `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/8xsOefuW_ZQ?si=nzKk8sgcK_QQqlVZ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
}, {
  id: "TanKnife2",
  techniqueName:'Vertical Slash',
  techniqueEquipment: ['Mouthpiece', 'Training Knife'],
  safety: `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.
    c. Do not make contact on the aggressor with the weapon.
    d. Conduct all practical application utilizing approved training gear.`,
  techniquePrinciples: {
    purpose:"",
    grip: "Your grip on the knife should be a natural and relaxed hammer grip with enough strength to hold the weapon while maintaining dexterity. From this position, the blade of the knife is always facing the aggressor.",
    stance: "The basic warrior stance is the foundation for knife techniques. The left arm will serve as a vertical shield protecting the head, neck, and torso. The weapon should be held at a level between the belt and chest, tight to the body to facilitate weapon retention.",
    movement:"Movement is used to open up different target areas of the body and avoid the aggressor’s strikes. Do not stand directly in front of the aggressor; they can rely on forward momentum to create the tactical advantage.",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "The objective in a knife fight is to attack vital target areas readily accessible such as the face, neck, torso, and groin. The extremities are secondary targets that are not immediately fatal, but will often open up fatal target areas, or become fatal if left unattended",
    anglesOfAttack: "There are six angles from which a knife attack can be launched: Vertically up or down, forward diagonal, reverse diagonal, forward horizontal, reverse horizontal, and a straight thrust.",
  },
  techniqueExecution: 
    `
    Thrusting techniques are more effective than slashing techniques because of the damage they can cause. The thrusting motion follows a vertical line straight up through the target.

        (1) Start facing the aggressor in the modified basic warrior stance.
        (2) Thrust your right hand toward the aggressor, inserting the knife blade straight into the target.
        (3) Pull the knife out of the aggressor.
        (4) Return to the modified basic warrior stance.
    `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/TpTzZsB-VJo?si=JdsAmlz3kWFywgyG" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
}];


