const tanChokes = [
{
  id: "01-chokes-tan",
  techniqueName: "Rear Choke",
  techniqueEquipment: [],
  safety: ``,
  techniquePrinciples: {
    purpose:"",
    principlesOverview: ``,
    grip: "",
    stance: "",
    movement:"",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    
    `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/LQqpWmQ01SI?si=nwW-DcVAubUvKucw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},
{
  id: "02-chokes-tan",
  techniqueName: "Figure-4 Variation",
  techniqueEquipment: [],
  safety: ``,
  techniquePrinciples: {
    purpose:"",
    principlesOverview: ``,
    grip: "",
    stance: "",
    movement:"",
  },
  techniqueFundamentals: {
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    
    `,
  proTip: "",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/dpHo0zG93mY?si=4GmmJ2zaLUBeEt3s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},
]; 