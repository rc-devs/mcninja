const tanCounters = [
  {
    id: "01-counter-tan",
    techniqueName: "Counter to a Rear Hand Punch",
    techniqueEquipment: [],
    safety: ``,
    techniquePrinciples: {
      purpose:"",
      principlesOverview: ``,
      grip: "",
      stance: "",
      movement:"",
    },
    techniqueFundamentals: {
      strikingSurface: "",
      targetAreas: "",
      anglesOfAttack: "",
    },
    techniqueExecution: 
      `
      
      `,
    proTip: "",
    video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/Pc6XYjf8D38?si=EAMRVe7-HqKdhxGe" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
  },
  {
    id: "02-counter-tan",
    techniqueName: "Counter to a Rear Leg Kick",
    techniqueEquipment: [],
    safety: ``,
    techniquePrinciples: {
      purpose:"",
      principlesOverview: ``,
      grip: "",
      stance: "",
      movement:"",
    },
    techniqueFundamentals: {
      strikingSurface: "",
      targetAreas: "",
      anglesOfAttack: "",
    },
    techniqueExecution: 
      `
      
      `,
    proTip: "",
    video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/GyKTEPl8Ag4?si=qaOWUH-USlqM-I_A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
  },
  {
    id: "03-counter-tan",
    techniqueName: "Counter to a Rear Choke",
    techniqueEquipment: [],
    safety: ``,
    techniquePrinciples: {
      purpose:"",
      principlesOverview: ``,
      grip: "",
      stance: "",
      movement:"",
    },
    techniqueFundamentals: {
      strikingSurface: "",
      targetAreas: "",
      anglesOfAttack: "",
    },
    techniqueExecution: 
      `
      
      `,
    proTip: "",
    video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/4QnblugW4ug?si=eNn9EBC9hfHuqo5D" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
  },
  {
    id: "04-counter-tan",
    techniqueName: "Counter to a Rear Headlock",
    techniqueEquipment: [],
    safety: ``,
    techniquePrinciples: {
      purpose:"",
      principlesOverview: ``,
      grip: "",
      stance: "",
      movement:"",
    },
    techniqueFundamentals: {
      strikingSurface: "",
      targetAreas: "",
      anglesOfAttack: "",
    },
    techniqueExecution: 
      `
      
      `,
    proTip: "",
    video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/6Cp5oh_g1ls?si=nUqcIPrE5OeaMWhU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
  },
  {
    id: "05-counter-tan",
    techniqueName: "Counter to a Rear Bearhug",
    techniqueEquipment: [],
    safety: ``,
    techniquePrinciples: {
      purpose:"",
      principlesOverview: ``,
      grip: "",
      stance: "",
      movement:"",
    },
    techniqueFundamentals: {
      strikingSurface: "",
      targetAreas: "",
      anglesOfAttack: "",
    },
    techniqueExecution: 
      `
      
      `,
    proTip: "",
    video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/Bcrml55kygg?si=aex2QmQ7L_kMBpIL" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
  },
  ]; 