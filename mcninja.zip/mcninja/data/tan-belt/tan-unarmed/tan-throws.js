const tanThrows = [{
  id: "01-Throw-Tan",
  techniqueName: "Leg Sweep",
  techniqueEquipment: [],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.
    c. Techniques will be performed on a soft-footed area.
    d. Students being thrown will execute proper break falls.
    e. Ensure calf on calf contact is made during training.
    g. Practice fit-ins when learning throws. To execute a fit-in, stop just before throwing the aggressor to the deck.
  `,
  techniquePrinciples: {
    purpose:"The purpose of a throw is to bring an aggressor to the deck to gain the tactical advantage in a fight.",
    principlesOverview:``,
    grip: "All throws must be properly timed to attack the aggressor when they are off-balance and vulnerable. You must put your body into a position that is optimal for the throw. If your position is incorrect, the aggressor can counter the throw",
    stance: "It is important to maintain control of your balance to prevent the aggressor from countering the throw. ",
    movement:"You will use the aggressor’s body as a lever to increase the power generated for the throw. Leverage will allow you to throw any aggressor of any size.",
  },
  techniqueFundamentals: {
    fundamentalsOverview: `
    (1) Entry. The first part of a throw is the entry. Your entry should be quick and un-telegraphed to prevent the aggressor from anticipating your movement and countering your attack. You also want to make sure your body positioning is correct in relation to your aggressor to allow for proper off-balancing and execution of the throw.
    (2) Off-Balancing. The second part of a throw is off-balancing. Off-balancing techniques are used to control an aggressor by using his momentum to move or throw him. This aids in the execution of throws because your aggressor is unable to fight your attack with his full strength when he is off-balanced.
      (a) Angles of Off-Balancing. There are eight angles or directions in which an aggressor can be off-balanced: forward, rear, right, left, forward right, forward left, rear right, and rear left. The angles correspond to your perspective, not the aggressor's.
      (b) Off-Balancing Techniques. An aggressor can be off-balanced by pushing, pulling, or bumping. Pushing and pulling are performed by grabbing the aggressor with your hands and driving him forcefully to one of the angles of off-balancing. Bumping uses other parts of your body such as your shoulders, hips, and legs to off-balance the aggressor.
      (c) Momentum. Off-balancing techniques rely on the momentum of the aggressor. For example, if the aggressor is charging at you, you can pull him to drive him to the deck. Likewise, if the aggressor is pulling on you, you can push him to drive him to the deck. Using momentum is particularly effective for Marines who are outsized by the aggressor.
    (3) Execution. The third and final part of a throw is the execution. The remaining steps in throwing the aggressor to the deck are utilized here. Each step before this is just to set up and assist in this final process. Follow through the throw to maximize power.`,
    strikingSurface: "",
    targetAreas: "",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    A leg sweep is particularly effective if the aggressor is moving backward or pulling on you.
      (1) Start facing the aggressor in the basic warrior stance.
      (2) Step forward with your left foot on the outside of the aggressor's right foot. Your foot should be on line or behind the aggressor's foot, and far enough outside to provide room to bring the other leg through to execute the sweep.
      (3) At the same time, grab the aggressor’s right wrist with your left hand and his left shoulder with your right hand. You may grab the aggressor's flesh, clothing, or gear.
      (4) Off-balance the aggressor by pulling his wrist downward close to your trouser pocket and pushing his shoulder backward.
      (5) Raise your right knee waist high and bring your foot behind the aggressor's right leg. The leg should be bent at the knee because it takes less movement than straightening the leg prior to the sweep. When your leg is raised you should be balanced while the aggressor is off-balance.
      (6) Sweep through the aggressor’s leg, making contact with your calf on the aggressor's calf. At the same time, continue to pull the aggressor’s right wrist and push his left shoulder.
      (7) Drive the aggressor to the deck by bending at the waist, and following through his leg with the sweep. Release your grip on the aggressor's shoulder in order to maintain your balance.
      (8) Rapidly return to the basic warrior stance.
    `,
  proTip: "Ensure calf on calf contact is being made. In a combative engagement contact will be made with the cutting edge of your heel on the aggressor’s Achilles tendon.",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/6dBm98BHzo8?si=ev5rtn8l97CVs6sJ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
}]; 