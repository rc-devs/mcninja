const tanPunches = [{
  id: "01-Punch-Tan",
  techniqueName: "Lead Hand Punch",
  techniqueEquipment: ['Striking Pad', 'Sparring Gloves'],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.
    c. When executing strikes, ensure the joints are kept slightly bent to avoid hyperextension.
  `,
  techniquePrinciples: {
    purpose:`The purpose of punches is to stun your enemy or to set them up for a follow on technique`,
    grip: ``,
    stance: "The principles for punches are muscle relaxation, making a fist, weight transfer, rapid retraction, and telegraphing.",
    movement:
    `
    (1) Muscle Relaxation. Muscle relaxation must be emphasized at all times during instruction on punches. The natural tendency in a fight is to tense up, which results in rapid fatigue and decreased power generation. The fighter who can remain relaxed during a close combat situation generates greater speed, which results in greater generation of power. Relaxing your forearm generates speed and improves reaction time. At the point of impact, clench your fist to cause damage to the aggressor and to avoid injury to your wrist and hand.

    (2) Making a Fist. Punches are executed using the basic fist. Curl the fingers naturally into the palm of the hand and place the thumb across the index and middle fingers. Do not clench the fist until movement has begun. This increases muscular tension in the forearm and decreases speed and reaction time. Just before impact, apply muscular tension to the hand and forearm to maximize damage to the aggressor and reduce injury to the MCNINJA.

    (3) Weight Transfer. Weight transfer is necessary to generate power in a punch. This is accomplished by rotating the hips and shoulders into the attack, moving your body mass forward, or dropping your body weight into an aggressor. Your body’s mass can be transferred into an attack from high to low or from low to high.

    (4) Rapid Retraction. When delivering a punch, quickly return to the basic warrior stance. Rapid retraction enables you to protect yourself from your aggressor’s counter-attack and prevents the aggressor from being able to grab your hand or arm. This also chambers the arm in preparation for delivering a subsequent punch.

    (4) Telegraphing. Telegraphing a strike informs the aggressor of your intentions to launch an attack through your body movements. Untrained fighters will often telegraph their attack by drawing their hand back, changing facial expression, tensing neck muscles, or twitching. These movements, however small, immediately indicate an attack is about to be delivered. Telegraphing against a trained fighter may enable him to evade or counter your attack. Even an untrained fighter may be able to minimize the effect of your attack. Staying relaxed helps to reduce telegraphing.
    `,
  },
  techniqueFundamentals: {
    strikingSurface: "The striking surface for all punches is the first two knuckles of your fist. Contact with the fist should be made with the knuckles of the index and middle finger in line with the wrist to avoid injury to the wrist",
    targetAreas: "Target areas that should be attacked with punches are soft tissue areas such as the nose, jaw, and throat. The torso can also be attacked as a secondary target.",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    The lead hand punch is a snapping straight punch executed by the forward or lead hand. It is a fast, unexpected punch designed to stun an aggressor and to set up for a follow-on techniques. A lead hand punch conceals movement and allows you to get close to the aggressor.
      (1) Assume the basic warrior stance.
      (2) Snap your lead hand out to nearly full extension, while rotating your palm to the deck.
      (3) Keep your rear hand in place to protect your head.
      (4) Rapidly retract to the basic warrior stance.
    `,
    proTip: "A common mistake is to pull the fist back low, leaving you open to a counter attack. Ensure you do not hyperextend your elbows",
    video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/8Oxwfhd_L0Q?si=ggknHEo16ij2KbMT" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
}, {
  id: "02-Punch-Tan",
  techniqueName: "Rear Hand Punch",
  techniqueEquipment: ['Striking Pad', 'Sparring Gloves'],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.
    c. When executing strikes, ensure the joints are kept slightly bent to avoid hyperextension.
  `,
  techniquePrinciples: {
    purpose:"The purpose of punches is to stun your enemy or to set them up for a follow on technique",
    grip: "",
    stance: "The principles for punches are muscle relaxation, making a fist, weight transfer, rapid retraction, and telegraphing.",
    movement:
    `
    (1) Muscle Relaxation. Muscle relaxation must be emphasized at all times during instruction on punches. The natural tendency in a fight is to tense up, which results in rapid fatigue and decreased power generation. The fighter who can remain relaxed during a close combat situation generates greater speed, which results in greater generation of power. Relaxing your forearm generates speed and improves reaction time. At the point of impact, clench your fist to cause damage to the aggressor and to avoid injury to your wrist and hand.

    (2) Making a Fist. Punches are executed using the basic fist. Curl the fingers naturally into the palm of the hand and place the thumb across the index and middle fingers. Do not clench the fist until movement has begun. This increases muscular tension in the forearm and decreases speed and reaction time. Just before impact, apply muscular tension to the hand and forearm to maximize damage to the aggressor and reduce injury to the MCNINJA.

    (3) Weight Transfer. Weight transfer is necessary to generate power in a punch. This is accomplished by rotating the hips and shoulders into the attack, moving your body mass forward, or dropping your body weight into an aggressor. Your body’s mass can be transferred into an attack from high to low or from low to high.

    (4) Rapid Retraction. When delivering a punch, quickly return to the basic warrior stance. Rapid retraction enables you to protect yourself from your aggressor’s counter-attack and prevents the aggressor from being able to grab your hand or arm. This also chambers the arm in preparation for delivering a subsequent punch.

    (4) Telegraphing. Telegraphing a strike informs the aggressor of your intentions to launch an attack through your body movements. Untrained fighters will often telegraph their attack by drawing their hand back, changing facial expression, tensing neck muscles, or twitching. These movements, however small, immediately indicate an attack is about to be delivered. Telegraphing against a trained fighter may enable him to evade or counter your attack. Even an untrained fighter may be able to minimize the effect of your attack. Staying relaxed helps to reduce telegraphing.
    `,
  },
  techniqueFundamentals: {
    strikingSurface: "The striking surface for all punches is the first two knuckles of your fist. Contact with the fist should be made with the knuckles of the index and middle finger in line with the wrist to avoid injury to the wrist",
    targetAreas: "Target areas that should be attacked with punches are soft tissue areas such as the nose, jaw, and throat. The torso can also be attacked as a secondary target.",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    The rear hand punch is a snapping punch executed by the rear hand. It is a power punch designed to inflict maximum damage on your aggressor. Its power comes from pushing off your rear leg and rotating your hips and shoulders.
      (1) Assume the basic warrior stance.
      (2) Forcefully rotate your hips and shoulders toward the aggressor and thrust your rear hand straight out, palm down, to nearly full extension.
      (3) Shift your body weight to your lead foot while pushing off on the ball of your rear foot.
      (4) Keep your lead hand in place to protect your head.
      (5) Rapidly retract to the basic warrior stance.
    `,
  proTip: "A common mistake is to pull the fist back low, leaving you open to a counter attack. Ensure you do not hyperextend your elbows",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/ofil5E5lPCY?si=vci54z7U6Vb-NFcL" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},{
  id: "03-Punch-Tan",
  techniqueName: "Uppercut",
  techniqueEquipment: ['Striking Pad', 'Sparring Gloves'],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.
    c. When executing strikes, ensure the joints are kept slightly bent to avoid hyperextension.
  `,
  techniquePrinciples: {
  purpose:"The purpose of punches is to stun your enemy or to set them up for a follow on technique",
  grip: "",
  stance: "The principles for punches are muscle relaxation, making a fist, weight transfer, rapid retraction, and telegraphing.",
  movement:
  `
  (1) Muscle Relaxation. Muscle relaxation must be emphasized at all times during instruction on punches. The natural tendency in a fight is to tense up, which results in rapid fatigue and decreased power generation. The fighter who can remain relaxed during a close combat situation generates greater speed, which results in greater generation of power. Relaxing your forearm generates speed and improves reaction time. At the point of impact, clench your fist to cause damage to the aggressor and to avoid injury to your wrist and hand.

  (2) Making a Fist. Punches are executed using the basic fist. Curl the fingers naturally into the palm of the hand and place the thumb across the index and middle fingers. Do not clench the fist until movement has begun. This increases muscular tension in the forearm and decreases speed and reaction time. Just before impact, apply muscular tension to the hand and forearm to maximize damage to the aggressor and reduce injury to the MCNINJA.

  (3) Weight Transfer. Weight transfer is necessary to generate power in a punch. This is accomplished by rotating the hips and shoulders into the attack, moving your body mass forward, or dropping your body weight into an aggressor. Your body’s mass can be transferred into an attack from high to low or from low to high.

  (4) Rapid Retraction. When delivering a punch, quickly return to the basic warrior stance. Rapid retraction enables you to protect yourself from your aggressor’s counter-attack and prevents the aggressor from being able to grab your hand or arm. This also chambers the arm in preparation for delivering a subsequent punch.

  (4) Telegraphing. Telegraphing a strike informs the aggressor of your intentions to launch an attack through your body movements. Untrained fighters will often telegraph their attack by drawing their hand back, changing facial expression, tensing neck muscles, or twitching. These movements, however small, immediately indicate an attack is about to be delivered. Telegraphing against a trained fighter may enable him to evade or counter your attack. Even an untrained fighter may be able to minimize the effect of your attack. Staying relaxed helps to reduce telegraphing.
  `,
},
techniqueFundamentals: {
  strikingSurface: "The striking surface for all punches is the first two knuckles of your fist. Contact with the fist should be made with the knuckles of the index and middle finger in line with the wrist to avoid injury to the wrist",
  targetAreas: "Target areas that should be attacked with punches are soft tissue areas such as the nose, jaw, and throat. The torso can also be attacked as a secondary target.",
  anglesOfAttack: "",
},
techniqueExecution: 
  `
  The uppercut is a powerful punch originating below the aggressor's line of vision. It is executed in an upward motion traveling up the centerline of the aggressor's body. It is delivered in close and usually follows a preparatory strike that leaves the target area unprotected. When delivered to the chin or jaw, the uppercut can render an aggressor unconscious, cause extensive damage to the neck, and/or sever the tongue.
      (1) Assume the basic warrior stance.
      (2) Rotate your fist so your palm is facing you. Ensure your lead hand stays up and in place to protect your head.
      (3) Power is generated from low to high. Start with your body weight low and legs slightly bent. Explode upwards with your legs, hips, and shoulders, driving your fist straight up through the target area.
      (4) Rapidly retract to the basic warrior stance
  `,
  proTip: "A common mistake is to drop the fist to the waist in an attempt to generate more power. Power is generated from the correct use of the lower body.",
  video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/5LXsw2VfrOg?si=YFUX3n1gZehr2fvi" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
},{
  id: "04-Punch-Tan",
  techniqueName: "Hook",
  techniqueEquipment: ['Striking Pad', 'Sparring Gloves'],
  safety: 
  `
  To prevent injury, ensure the following:
    a. Start slowly and increase speed with proficiency.
    b. Never execute techniques at full force or full speed.
    c. When executing strikes, ensure the joints are kept slightly bent to avoid hyperextension.
  `,
  techniquePrinciples: {
    purpose:"The purpose of punches is to stun your enemy or to set them up for a follow on technique",
    grip: "",
    stance: "The principles for punches are muscle relaxation, making a fist, weight transfer, rapid retraction, and telegraphing.",
    movement:
    `
    (1) Muscle Relaxation. Muscle relaxation must be emphasized at all times during instruction on punches. The natural tendency in a fight is to tense up, which results in rapid fatigue and decreased power generation. The fighter who can remain relaxed during a close combat situation generates greater speed, which results in greater generation of power. Relaxing your forearm generates speed and improves reaction time. At the point of impact, clench your fist to cause damage to the aggressor and to avoid injury to your wrist and hand.
  
    (2) Making a Fist. Punches are executed using the basic fist. Curl the fingers naturally into the palm of the hand and place the thumb across the index and middle fingers. Do not clench the fist until movement has begun. This increases muscular tension in the forearm and decreases speed and reaction time. Just before impact, apply muscular tension to the hand and forearm to maximize damage to the aggressor and reduce injury to the MCNINJA.
  
    (3) Weight Transfer. Weight transfer is necessary to generate power in a punch. This is accomplished by rotating the hips and shoulders into the attack, moving your body mass forward, or dropping your body weight into an aggressor. Your body’s mass can be transferred into an attack from high to low or from low to high.
  
    (4) Rapid Retraction. When delivering a punch, quickly return to the basic warrior stance. Rapid retraction enables you to protect yourself from your aggressor’s counter-attack and prevents the aggressor from being able to grab your hand or arm. This also chambers the arm in preparation for delivering a subsequent punch.
  
    (4) Telegraphing. Telegraphing a strike informs the aggressor of your intentions to launch an attack through your body movements. Untrained fighters will often telegraph their attack by drawing their hand back, changing facial expression, tensing neck muscles, or twitching. These movements, however small, immediately indicate an attack is about to be delivered. Telegraphing against a trained fighter may enable him to evade or counter your attack. Even an untrained fighter may be able to minimize the effect of your attack. Staying relaxed helps to reduce telegraphing.
    `,
  },
  techniqueFundamentals: {
    strikingSurface: "The striking surface for all punches is the first two knuckles of your fist. Contact with the fist should be made with the knuckles of the index and middle finger in line with the wrist to avoid injury to the wrist",
    targetAreas: "Target areas that should be attacked with punches are soft tissue areas such as the nose, jaw, and throat. The torso can also be attacked as a secondary target.",
    anglesOfAttack: "",
  },
  techniqueExecution: 
    `
    The hook is a powerful punch that is executed close-in and is usually preceded by a preparatory strike.
        (1) Assume the basic warrior stance.
        (2) Rotate your rear fist, this will parallel your fist and forearm to the deck.
        (3) Power is generated from side to side by driving with your legs and rotating your hips and shoulders. Your body’srotation drives the fist through your target area as your lead hand stays up and in place to protect your head.
        (4) Rapidly retract to the basic warrior stance.
    `,
  proTip: "A common mistake is to reach or extend the fist all the way out in an attempt to generate more power. Power is generated from the rotation of the hips and shoulders.",
  video: '<iframe width="560" height="315" src="https://www.youtube.com/embed/_nCUoFrqibk?si=CLu3yeW1XYfNr4w9" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>',
  }
];



//testlog
/* tanPunches.forEach((property)=> {
  console.log(property.techniqueName); */
/* console.log(property.techniqueEquipment);
console.log(property.safety);
console.log(property.techniquePrinciples.purpose);
console.log(property.techniquePrinciples.grip);
console.log(property.techniquePrinciples.stance);
console.log(property.techniquePrinciples.movement);
console.log(property.techniqueFundamentals.strikingSurface);
console.log(property.techniqueFundamentals.targetAreas);
console.log(property.techniqueFundamentals.anglesOfAttack);
console.log(property.techniqueExecution);
console.log(property.proTip);

 */