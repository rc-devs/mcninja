const tanLowerBodyStrikes = [
  {
    id: "01-lower-strike-tan",
    techniqueName: "Front Kick",
    techniqueEquipment: [],
    safety: ``,
    techniquePrinciples: {
      purpose:"",
      principlesOverview: ``,
      grip: "",
      stance: "",
      movement:"",
    },
    techniqueFundamentals: {
      strikingSurface: "",
      targetAreas: "",
      anglesOfAttack: "",
    },
    techniqueExecution: 
      `
      
      `,
    proTip: "",
    video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/JJdXqRpzp5o?si=ISnypdLCOcAFdi_r" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
  },
  {
    id: "02-lower-strike-tan",
    techniqueName: "Round Kick",
    techniqueEquipment: [],
    safety: ``,
    techniquePrinciples: {
      purpose:"",
      principlesOverview: ``,
      grip: "",
      stance: "",
      movement:"",
    },
    techniqueFundamentals: {
      strikingSurface: "",
      targetAreas: "",
      anglesOfAttack: "",
    },
    techniqueExecution: 
      `
      
      `,
    proTip: "",
    video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/R1x5rcb7aUA?si=Dajj3_DSsFHhIrTW" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
  },
  {
    id: "03-lower-strike-tan",
    techniqueName: "Vertical Knee Strike",
    techniqueEquipment: [],
    safety: ``,
    techniquePrinciples: {
      purpose:"",
      principlesOverview: ``,
      grip: "",
      stance: "",
      movement:"",
    },
    techniqueFundamentals: {
      strikingSurface: "",
      targetAreas: "",
      anglesOfAttack: "",
    },
    techniqueExecution: 
      `
      
      `,
    proTip: "",
    video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/ZaRTJZwXorI?si=4cpuIpwKyyG5tqbq" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
    // <iframe width="560" height="315" src="https://www.youtube.com/embed/DEhzD274t6A?si=TZ_Rk8lP5qt0ESjA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
  },
  {
    id: "04-lower-strike-tan",
    techniqueName: "Vertical Stomp",
    techniqueEquipment: [],
    safety: ``,
    techniquePrinciples: {
      purpose:"",
      principlesOverview: ``,
      grip: "",
      stance: "",
      movement:"",
    },
    techniqueFundamentals: {
      strikingSurface: "",
      targetAreas: "",
      anglesOfAttack: "",
    },
    techniqueExecution: 
      `
      
      `,
    proTip: "",
    video: `<iframe width="560" height="315" src="https://www.youtube.com/embed/K_JpSishBiI?si=Q95JYAvmgiW1mwSE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
  },
  ]; 